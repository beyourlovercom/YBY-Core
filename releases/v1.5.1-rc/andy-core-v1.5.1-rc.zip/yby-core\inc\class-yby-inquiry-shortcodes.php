<?php
/**
 * Inquiry shortcode registration.
 *
 * @package YBY_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and renders inquiry shortcodes.
 */
class YBY_Inquiry_Shortcodes {

	/**
	 * Inquiry manager.
	 *
	 * @var YBY_Inquiry_Manager
	 */
	protected $inquiry_manager;

	/**
	 * Inquiry renderer.
	 *
	 * @var YBY_Inquiry_Renderer
	 */
	protected $renderer;

	/**
	 * Used modal ID counts for deterministic suffixing.
	 *
	 * @var array<string, int>
	 */
	protected static $modal_id_counts = array();

	/**
	 * Deferred modal markup collected during shortcode rendering.
	 *
	 * @var array<string, string>
	 */
	protected static $deferred_modals = array();

	/**
	 * Request-level cache of transformed content by stable signature.
	 *
	 * @var array<string, string>
	 */
	protected static $content_render_cache = array();

	/**
	 * Constructor.
	 *
	 * @param YBY_Inquiry_Manager  $inquiry_manager Inquiry manager.
	 * @param YBY_Inquiry_Renderer $renderer Inquiry renderer.
	 */
	public function __construct( $inquiry_manager, $renderer ) {
		$this->inquiry_manager = $inquiry_manager;
		$this->renderer        = $renderer;
	}

	/**
	 * Register inquiry shortcodes.
	 *
	 * @return void
	 */
	public function register() {
		add_shortcode(
			'yby_inquiry_modal',
			array( $this, 'render_modal_shortcode' )
		);

		add_shortcode(
			'yby_sticky_cta',
			array( $this, 'render_sticky_cta_shortcode' )
		);
	}

	/**
	 * Render the inquiry modal shortcode.
	 *
	 * @param array<string, mixed> $attributes Shortcode attributes.
	 * @param string|null          $content Shortcode content.
	 * @param string               $tag Shortcode tag.
	 * @return string
	 */
	public function render_modal_shortcode( $attributes = array(), $content = null, $tag = '' ) {
		unset( $content, $tag );

		$attributes = $this->sanitize_shortcode_attributes( $attributes );

		if ( '' === $attributes['preset'] ) {
			$attributes['preset'] = $this->get_default_modal_preset( $attributes );
		}

		$preset_manager = $this->inquiry_manager->get_preset_manager();
		$preset         = $preset_manager->get_preset( $attributes['preset'] );

		if ( ! is_array( $preset ) || empty( $preset['enabled'] ) ) {
			$this->maybe_doing_it_wrong( 'The requested inquiry preset is missing or disabled.' );
			return '';
		}

		$fields = $this->resolve_preset_fields( $preset );

		if ( empty( $fields ) ) {
			return '';
		}

		$attributes['id'] = $this->generate_unique_modal_id(
			'' !== $attributes['id'] ? $attributes['id'] : 'yby-inquiry-modal-' . $preset['id']
		);

		$modal_markup = $this->renderer->render_modal( $preset, $fields, $attributes );

		if ( '' === $modal_markup ) {
			return '';
		}

		self::$deferred_modals[ $attributes['id'] ] = $modal_markup;

		return '<!-- yby_inquiry_modal:' . esc_html( $attributes['id'] ) . ' -->';
	}

	/**
	 * Render the shared sticky CTA shortcode.
	 *
	 * @param array<string, mixed> $attributes Shortcode attributes.
	 * @param string|null          $content Shortcode content.
	 * @param string               $tag Shortcode tag.
	 * @return string
	 */
	public function render_sticky_cta_shortcode( $attributes = array(), $content = null, $tag = '' ) {
		unset( $content, $tag );

		$attributes = $this->sanitize_sticky_cta_attributes( $attributes );
		$classes    = array_merge( array( 'yby-sticky-cta' ), $attributes['class'] );

		$output  = '<div id="' . esc_attr( $attributes['id'] ) . '" class="' . esc_attr( implode( ' ', $classes ) ) . '" data-yby-sticky-cta';
		$output .= '' !== $attributes['profile'] ? ' data-yby-page-profile="' . esc_attr( $attributes['profile'] ) . '"' : '';
		$output .= '>';
		$output .= '<a class="yby-sticky-cta__button" href="' . esc_url( $attributes['href'] ) . '" data-yby-inquiry-trigger data-yby-source="' . esc_attr( $attributes['source'] ) . '"';
		$output .= '' !== $attributes['modal_id'] ? ' data-yby-modal-open="' . esc_attr( $attributes['modal_id'] ) . '"' : '';
		$output .= '' !== $attributes['profile'] ? ' data-yby-page-profile="' . esc_attr( $attributes['profile'] ) . '"' : '';
		$output .= '>';
		$output .= esc_html( $attributes['label'] );
		$output .= '</a>';
		$output .= '</div>';

		return $output;
	}

	/**
	 * Print deferred modal markup in the footer.
	 *
	 * @return void
	 */
	public function render_deferred_modals() {
		if ( empty( self::$deferred_modals ) ) {
			return;
		}

		foreach ( self::$deferred_modals as $modal_markup ) {
			echo $modal_markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	/**
	 * Capture inquiry modals before other content filters strip the shortcode markup.
	 *
	 * @param string $content Raw content.
	 * @return string
	 */
	public function capture_modal_shortcodes_in_content( $content ) {
		if ( ! is_string( $content ) || false === strpos( $content, '[yby_inquiry_modal' ) ) {
			return $content;
		}

		$signature = $this->build_content_signature( $content );

		if ( isset( self::$content_render_cache[ $signature ] ) ) {
			return self::$content_render_cache[ $signature ];
		}

		$pattern = get_shortcode_regex( array( 'yby_inquiry_modal' ) );

		if ( empty( $pattern ) ) {
			return $content;
		}

		$transformed = preg_replace_callback(
			'/' . $pattern . '/',
			static function ( $matches ) {
				$shortcode_markup = isset( $matches[0] ) ? $matches[0] : '';

				return '' !== $shortcode_markup ? do_shortcode( $shortcode_markup ) : '';
			},
			$content
		);

		if ( is_string( $transformed ) ) {
			self::$content_render_cache[ $signature ] = $transformed;
			return $transformed;
		}

		return $content;
	}

	/**
	 * Reset request-level static state.
	 *
	 * @return void
	 */
	public static function reset_request_state() {
		self::$modal_id_counts      = array();
		self::$deferred_modals      = array();
		self::$content_render_cache = array();
	}

	/**
	 * Sanitize shortcode attributes.
	 *
	 * @param array<string, mixed> $attributes Raw attributes.
	 * @return array<string, mixed>
	 */
	protected function sanitize_shortcode_attributes( $attributes ) {
		$attributes = shortcode_atts(
			array(
				'id'           => '',
				'preset'       => '',
				'title'        => '',
				'submit_label' => '',
				'image'        => '',
				'class'        => '',
			),
			is_array( $attributes ) ? $attributes : array(),
			'yby_inquiry_modal'
		);

		return array(
			'id'           => $this->sanitize_dom_id( $attributes['id'] ),
			'preset'       => sanitize_key( $attributes['preset'] ),
			'title'        => sanitize_text_field( $attributes['title'] ),
			'submit_label' => sanitize_text_field( $attributes['submit_label'] ),
			'image'        => esc_url_raw( $attributes['image'] ),
			'class'        => $this->sanitize_class_tokens( $attributes['class'] ),
		);
	}

	/**
	 * Sanitize sticky CTA shortcode attributes.
	 *
	 * @param array<string, mixed> $attributes Raw attributes.
	 * @return array<string, mixed>
	 */
	protected function sanitize_sticky_cta_attributes( $attributes ) {
		$attributes = shortcode_atts(
			array(
				'id'       => 'yby-sticky-cta',
				'label'    => 'Get Quote',
				'href'     => '#yby-inquiry',
				'modal_id' => '',
				'source'   => 'site_global_sticky_cta',
				'profile'  => '',
				'class'    => '',
			),
			is_array( $attributes ) ? $attributes : array(),
			'yby_sticky_cta'
		);

		$source = str_replace( '-', '_', sanitize_key( $attributes['source'] ) );
		$source = '' !== $source ? $source : 'site_global_sticky_cta';
		$id     = $this->sanitize_dom_id( $attributes['id'] );
		$label  = sanitize_text_field( $attributes['label'] );

		return array(
			'id'       => '' !== $id ? $id : 'yby-sticky-cta',
			'label'    => '' !== $label ? $label : 'Get Quote',
			'href'     => $this->sanitize_anchor_or_url( $attributes['href'] ),
			'modal_id' => $this->sanitize_dom_id( $attributes['modal_id'] ),
			'source'   => $source,
			'profile'  => str_replace( '-', '_', sanitize_key( $attributes['profile'] ) ),
			'class'    => $this->sanitize_class_tokens( $attributes['class'] ),
		);
	}

	/**
	 * Return the default modal preset ID.
	 *
	 * @param array<string, mixed> $attributes Sanitized shortcode attributes.
	 * @return string
	 */
	protected function get_default_modal_preset( $attributes ) {
		$default = 'irrigation_quick_inquiry';

		if ( function_exists( 'apply_filters' ) ) {
			$default = apply_filters( 'yby_inquiry_default_preset', $default, $attributes );
		}

		return sanitize_key( $default );
	}

	/**
	 * Sanitize a local anchor or URL.
	 *
	 * @param string $value Raw URL.
	 * @return string
	 */
	protected function sanitize_anchor_or_url( $value ) {
		$value = trim( (string) $value );

		if ( preg_match( '/^#[A-Za-z][A-Za-z0-9_-]*$/', $value ) ) {
			return $value;
		}

		$url = esc_url_raw( $value );

		return '' !== $url ? $url : '#yby-inquiry';
	}

	/**
	 * Resolve preset fields in preset order.
	 *
	 * @param array<string, mixed> $preset Preset definition.
	 * @return array<int, array<string, mixed>>
	 */
	protected function resolve_preset_fields( $preset ) {
		$field_manager = $this->inquiry_manager->get_field_manager();
		$all_fields    = $field_manager->get_fields();
		$resolved      = array();

		foreach ( isset( $preset['fields'] ) && is_array( $preset['fields'] ) ? $preset['fields'] : array() as $field_id ) {
			$field_id = sanitize_key( $field_id );

			if ( '' === $field_id || ! isset( $all_fields[ $field_id ] ) ) {
				continue;
			}

			$field = $all_fields[ $field_id ];

			if ( empty( $field['enabled'] ) || empty( $field['type'] ) ) {
				continue;
			}

			$resolved[] = $field;
		}

		return $resolved;
	}

	/**
	 * Sanitize a DOM ID token.
	 *
	 * @param string $value Raw ID value.
	 * @return string
	 */
	protected function sanitize_dom_id( $value ) {
		$value = trim( (string) $value );

		if ( '' === $value ) {
			return '';
		}

		$parts = preg_split( '/[^A-Za-z0-9_-]+/', $value, -1, PREG_SPLIT_NO_EMPTY );
		$parts = is_array( $parts ) ? $parts : array();

		return implode( '-', array_map( array( $this, 'sanitize_single_html_class' ), $parts ) );
	}

	/**
	 * Sanitize class tokens.
	 *
	 * @param string $value Raw class string.
	 * @return array<int, string>
	 */
	protected function sanitize_class_tokens( $value ) {
		$tokens    = preg_split( '/\s+/', (string) $value, -1, PREG_SPLIT_NO_EMPTY );
		$tokens    = is_array( $tokens ) ? $tokens : array();
		$sanitized = array();

		foreach ( $tokens as $token ) {
			$token = $this->sanitize_single_html_class( $token );

			if ( '' === $token || in_array( $token, $sanitized, true ) ) {
				continue;
			}

			$sanitized[] = $token;
		}

		return $sanitized;
	}

	/**
	 * Sanitize one class-safe token.
	 *
	 * @param string $value Raw token.
	 * @return string
	 */
	protected function sanitize_single_html_class( $value ) {
		if ( function_exists( 'sanitize_html_class' ) ) {
			return sanitize_html_class( (string) $value );
		}

		return preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $value );
	}

	/**
	 * Generate a deterministic unique modal ID.
	 *
	 * @param string $base_id Base modal ID.
	 * @return string
	 */
	protected function generate_unique_modal_id( $base_id ) {
		$base_id = $this->sanitize_dom_id( $base_id );
		$base_id = '' !== $base_id ? $base_id : 'yby-inquiry-modal';

		if ( ! isset( self::$modal_id_counts[ $base_id ] ) ) {
			self::$modal_id_counts[ $base_id ] = 1;
			return $base_id;
		}

		self::$modal_id_counts[ $base_id ]++;

		return $base_id . '-' . self::$modal_id_counts[ $base_id ];
	}

	/**
	 * Build a stable request-level content signature.
	 *
	 * @param string $content Raw content.
	 * @return string
	 */
	protected function build_content_signature( $content ) {
		$post_id = 0;

		if ( isset( $GLOBALS['post']->ID ) ) {
			$post_id = (int) $GLOBALS['post']->ID;
		} elseif ( function_exists( 'get_the_ID' ) ) {
			$post_id = (int) get_the_ID();
		}

		return $post_id . ':' . md5( $content );
	}

	/**
	 * Emit a safe developer notice for invalid shortcode usage.
	 *
	 * @param string $message Notice message.
	 * @return void
	 */
	protected function maybe_doing_it_wrong( $message ) {
		if ( function_exists( '_doing_it_wrong' ) ) {
			_doing_it_wrong( __METHOD__, esc_html( $message ), '1.3.0-dev' );
		}
	}
}
